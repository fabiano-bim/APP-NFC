
package com.example.nfcemulator

import android.app.Activity
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.os.Bundle
import android.widget.*

class MainActivity : Activity() {

    private lateinit var tagIdInput: EditText
    private lateinit var tagNameInput: EditText
    private lateinit var tagList: Spinner
    private lateinit var saveButton: Button
    private lateinit var emulateButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tagIdInput = findViewById(R.id.tag_id_input)
        tagNameInput = findViewById(R.id.tag_name_input)
        tagList = findViewById(R.id.tag_list)
        saveButton = findViewById(R.id.save_button)
        emulateButton = findViewById(R.id.emulate_button)

        // Listeners and dummy list
        saveButton.setOnClickListener {
            Toast.makeText(this, "Tag saved locally", Toast.LENGTH_SHORT).show()
        }

        emulateButton.setOnClickListener {
            Toast.makeText(this, "Tag emulated", Toast.LENGTH_SHORT).show()
        }
    }
}
